import 'package:flutter/material.dart';
import 'Questionsbag.dart';
import 'package:rflutter_alert/rflutter_alert.dart';

Questionsbag questionsbag = Questionsbag();

void main() {
  runApp(const Project());
}


class Project extends StatelessWidget {
  const Project({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(
          backgroundColor: Colors.blueGrey,
            title: const Text('Road signs test')
        ),
        body: const Padding(
          padding: EdgeInsets.all(20.0),
          child: Testpage(),
        ),
      ),
    );
  }
}
class Testpage extends StatefulWidget {
  const Testpage({super.key});

  @override
  State<Testpage> createState() => _TestpageState();
}

class _TestpageState extends State<Testpage> {
  List<Widget> answerResult = [];
  int rightanswer = 0;
  List<String> shuffledChoices = [];

  @override
  void initState() {
    super.initState();
    shuffledChoices = questionsbag.getShuffledChoices();
  }

  void checkAnswer(String selectedChoice ) {
    String correctAnswer = questionsbag.getQuestionAnswer();
      setState(() {
        if (selectedChoice == correctAnswer) {
          rightanswer ++;
          answerResult.add(const Padding(
            padding: EdgeInsets.all(6.0),
            child: Icon(Icons.check,
              color: Colors.green,
            ),
          ),
          );
        }
        else {
          answerResult.add(const Padding(
            padding: EdgeInsets.all(6.0),
            child: Icon(Icons.close,
              color: Colors.red,
            ),
          ),
          );
        }
        if (questionsbag.isFinished() == true){
          if (rightanswer >= 7) {
            Alert(
              context: context,
              title: "Test is done",
              desc: "You have succeed",
              buttons: [
                DialogButton(
                  child: Text(
                    "start again?",
                    style: TextStyle(color: Colors.white, fontSize: 18),
                  ),
                  onPressed: () => Navigator.pop(context),
                  width: 120,
                )
              ],
            ).show();
          }else{
            Alert(
              context: context,
              title: "Test is done",
              desc: "You have failed",
              buttons: [
                DialogButton(
                  child: Text(
                    "Start again?",
                    style: TextStyle(color: Colors.white, fontSize: 18),
                  ),
                  onPressed: () => Navigator.pop(context),
                  width: 120,
                )
              ],
            ).show();
          }
          questionsbag.reset();
          answerResult = [];
          rightanswer = 0;
          shuffledChoices = questionsbag.getShuffledChoices();
        } else {
          questionsbag.nextquestion();
          shuffledChoices = questionsbag.getShuffledChoices();
        }
      });
    }
@override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Row(
          children: answerResult,
        ),
        Expanded(
          child: Column(children: [
            Image.asset(questionsbag.getQuestionImage()),
            const SizedBox(height: 20.0,),
            Text(questionsbag.getQuestionText(),
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 24.0, color: Colors.black,),
            ),
              ],
            ),
        ),
        for (var choice in shuffledChoices)
          Expanded(
            child: Padding(
              padding: const EdgeInsets.symmetric(vertical: 10.0),
              child: TextButton(
                style: TextButton.styleFrom(backgroundColor: Colors.indigo),
                child: Text(
                  choice,
                  textAlign: TextAlign.center,
                  style: const TextStyle(fontSize: 15.0, color: Colors.white),
                ),
                onPressed: () => checkAnswer(choice),
              ),
            ),
          ),
      ],
    );
}
}

