import 'question.dart';
import 'dart:math';

class Questionsbag {
  int _questionN = 0;
  final List<Question> _questions = [
    Question(questionImage: 'image/3-1-1.jpg',
        questionText: 'What does this sign mean?',
        questionAnswer: 1,
        choices: [
          'It warns that railway tracks cross the road. Watch for this sign. Slow down and look both ways for trains. Be prepared to stop.',
          'It warns that you are coming to a school zone. Slow down, drive with extra caution and watch for children.',
          'No pedestrians allowed on this road.',
        ],
    ),
    Question(questionImage: 'image/3-1-2.jpg',
        questionText: 'What does this sign mean?',
        questionAnswer: 1,
      choices: [
        'Do not drive through the intersection.',
        'Stop at the stop line if it is marked on the pavement. If there is no stop line, stop at the crosswalk. If there is no crosswalk, stop at the edge of the sidewalk. If there is no sidewalk, stop at the edge of the intersection. Wait until the way is clear before entering the intersection.',
        'Do not turn to go in the opposite direction. (U-turn)',
      ],
    ),
    Question(questionImage: 'image/3-1-3.jpg',
        questionText: 'What does this sign mean?',
        questionAnswer: 1,
      choices: [
        'It warns that railway tracks cross the road. Watch for this sign. Slow down and look both ways for trains. Be prepared to stop.',
        'It means you must let traffic in the intersection or close to it go first. Stop if necessary and go only when the way is clear.',
        'Do not drive through the intersection.',
      ],
    ),
    Question(questionImage: 'image/3-1-4.jpg',
        questionText: 'What does this sign mean?',
        questionAnswer: 1,
      choices: [
        'Keep to the right of the traffic island.',
        'It warns that railway tracks cross the road. Watch for this sign. Slow down and look both ways for trains. Be prepared to stop.',
        'Stop at the stop line if it is marked on the pavement. If there is no stop line, stop at the crosswalk. If there is no crosswalk, stop at the edge of the sidewalk. If there is no sidewalk, stop at the edge of the intersection. Wait until the way is clear before entering the intersection.',
      ],
    ),
    Question(questionImage: 'image/3-1-5.jpg',
        questionText: 'What does this sign mean?',
        questionAnswer: 1,
      choices: [
        'It warns that you are coming to a school zone. Slow down, drive with extra caution and watch for children.',
        'Do not drive through the intersection.',
        'Do not turn to go in the opposite direction. (U-turn)',
      ],
    ),
    Question(questionImage: 'image/3-1-6.jpg',
        questionText: 'What does this sign mean?',
        questionAnswer: 1,
      choices: [
        'It warns that railway tracks cross the road. Watch for this sign. Slow down and look both ways for trains. Be prepared to stop.',
        'Do not turn to go in the opposite direction. (U-turn)',
        'Keep to the right of the traffic island.',
      ],
    ),
    Question(questionImage: 'image/3-1-7.jpg',
        questionText: 'What does this sign mean?',
        questionAnswer: 1,
      choices: [
        'It means you must let traffic in the intersection or close to it go first. Stop if necessary and go only when the way is clear.',
        'Do not turn right when facing a red light at the intersection.',
        'No pedestrians allowed on this road.',
      ],
    ),
    Question(questionImage: 'image/3-1-8.jpg',
        questionText: 'What does this sign mean?',
        questionAnswer: 1,
      choices: [
        'It warns that railway tracks cross the road. Watch for this sign. Slow down and look both ways for trains. Be prepared to stop.',
        'Do not turn left during the times shown.',
        'It warns that you are coming to a school zone. Slow down, drive with extra caution and watch for children.',
      ],
    ),
    Question(questionImage: 'image/3-1-9.jpg',
        questionText: 'What does this sign mean?',
        questionAnswer: 1,
      choices: [
        'It warns that you are coming to a school zone. Slow down, drive with extra caution and watch for children.',
        'No pedestrians allowed on this road.',
        'Stop at the stop line if it is marked on the pavement. If there is no stop line, stop at the crosswalk. If there is no crosswalk, stop at the edge of the sidewalk. If there is no sidewalk, stop at the edge of the intersection. Wait until the way is clear before entering the intersection.',
      ],
    ),
    Question(questionImage: 'image/3-1-10.jpg',
        questionText: 'What does this sign mean?',
        questionAnswer: 1,
      choices: [
        'It means you must let traffic in the intersection or close to it go first. Stop if necessary and go only when the way is clear.',
        'Keep to the right of the traffic island.',
        'Do not drive through the intersection.',
      ],
    ),
  ];

  void nextquestion() {
    if (_questionN < _questions.length - 1) {
      _questionN ++;
    }
  }

  String getQuestionImage() {
    return _questions[_questionN].questionImage;
  }

  String getQuestionText() {
    return _questions[_questionN].questionText;
  }

  List<String> getShuffledChoices() {
    List<String> choices = List.from(_questions[_questionN].choices);
    choices.shuffle(Random());
    return choices;
  }

  String getQuestionAnswer() {
    return _questions[_questionN].choices[_questions[_questionN].questionAnswer];
  }

  bool isFinished() {
    if (_questionN >= _questions.length - 1) {
      return true;
    } else {
      return false;
    }
  }
  void reset() {_questionN = 0;}
}