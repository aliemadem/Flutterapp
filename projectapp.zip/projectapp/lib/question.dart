class Question {
  String questionImage;
  String questionText;
  int questionAnswer;
  List<String> choices;

  Question({required this.questionImage, required this.questionText, required this.questionAnswer, required this.choices});
}
